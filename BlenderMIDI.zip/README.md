# BlenderMIDI

Control Blender via MIDI